using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeApp
{
    // Main class to run the application
    internal class Program
    {
        private static void Main(string[] args)
        {
            // Create a list to store multiple recipes
            List<Recipe> recipes = new List<Recipe>();
            bool appRunning = true;

            while (appRunning)
            {
                Console.WriteLine("Recipe App Menu:");
                Console.WriteLine("1. Enter a new recipe");
                Console.WriteLine("2. View all recipes");
                Console.WriteLine("3. Exit");

                Console.Write("Select an option: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Recipe newRecipe = RecipeManager.EnterRecipe();
                        recipes.Add(newRecipe);
                        break;
                    case "2":
                        RecipeManager.ViewAllRecipes(recipes);
                        break;
                    case "3":
                        appRunning = false;
                        Console.WriteLine("Exiting Recipe App. Goodbye!");
                        break;
                    default:
                        Console.WriteLine("Invalid input. Please enter a valid option.");
                        break;
                }

                Console.WriteLine();
            }
        }
    }

    // Class to manage recipe operations
    internal static class RecipeManager
    {
        // Delegate to notify when a recipe exceeds 300 calories
        public delegate void RecipeExceedsCaloriesHandler(Recipe recipe);

        // Event triggered when a recipe exceeds 300 calories
        public static event RecipeExceedsCaloriesHandler RecipeExceedsCaloriesEvent;

        // Method to enter a new recipe
        public static Recipe EnterRecipe()
        {
            Console.Write("Enter the recipe name: ");
            string recipeName = Console.ReadLine();

            Recipe newRecipe = new Recipe(recipeName);

            Console.Write("Enter the number of ingredients: ");
            int numIngredients = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < numIngredients; i++)
            {
                Console.Write($"Ingredient {i + 1} Name: ");
                string name = Console.ReadLine();

                Console.Write($"Quantity for {name}: ");
                double quantity = Convert.ToDouble(Console.ReadLine());

                Console.Write($"Unit of measurement for {name}: ");
                string unit = Console.ReadLine();

                Console.Write($"Calories for {name}: ");
                double calories = Convert.ToDouble(Console.ReadLine());

                Console.Write($"Food group for {name}: ");
                string foodGroup = Console.ReadLine();

                newRecipe.AddIngredient(new Ingredient(name, quantity, unit, calories, foodGroup));
            }

            Console.Write("Enter the number of steps: ");
            int numSteps = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Step {i + 1}: ");
                string description = Console.ReadLine();

                newRecipe.AddStep(new RecipeStep(description));
            }

            return newRecipe;
        }

        // Method to view all recipes
        public static void ViewAllRecipes(List<Recipe> recipes)
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes available.");
                return;
            }

            Console.WriteLine("Recipes:");
            foreach (Recipe recipe in recipes.OrderBy(r => r.Name))
            {
                Console.WriteLine(recipe.Name);
            }

            Console.Write("Enter the name of the recipe to view: ");
            string recipeName = Console.ReadLine();

            Recipe selectedRecipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));

            if (selectedRecipe != null)
            {
                Console.WriteLine(selectedRecipe);
            }
            else
            {
                Console.WriteLine("Recipe not found.");
            }
        }

        // Method to calculate total calories of a recipe
        public static double CalculateTotalCalories(Recipe recipe)
        {
            double totalCalories = 0;
            foreach (Ingredient ingredient in recipe.Ingredients)
            {
                totalCalories += ingredient.Calories;
            }
            return totalCalories;
        }
    }

    // Class to represent a recipe
    internal class Recipe
    {
        public string Name { get; }
        public List<Ingredient> Ingredients { get; }
        public List<RecipeStep> Steps { get; }

        public Recipe(string name)
        {
            Name = name;
            Ingredients = new List<Ingredient>();
            Steps = new List<RecipeStep>();
        }

        public void AddIngredient(Ingredient ingredient)
        {
            Ingredients.Add(ingredient);
            double totalCalories = RecipeManager.CalculateTotalCalories(this);
            if (totalCalories > 300)
            {
                RecipeManager.RecipeExceedsCaloriesEvent?.Invoke(this);
            }
        }

        public void AddStep(RecipeStep step)
        {
            Steps.Add(step);
        }

        public override string ToString()
        {
            string recipeString = $"Recipe: {Name}\n";
            recipeString += "Ingredients:\n";
            foreach (Ingredient ingredient in Ingredients)
            {
                recipeString += $"{ingredient}\n";
            }

            recipeString += "\nSteps:\n";
            for (int i = 0; i < Steps.Count; i++)
            {
                recipeString += $"{i + 1}. {Steps[i]}\n";
            }

            return recipeString;
        }
    }

    // Class to represent an ingredient
    internal class Ingredient
    {
        public string Name { get; }
        public double Quantity { get; }
        public string Unit { get; }
        public double Calories { get; }
        public string FoodGroup { get; }

        public Ingredient(string name, double quantity, string unit, double calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }

        public override string ToString()
        {
            return $"{Quantity} {Unit} of {Name}, Calories: {Calories}, Food Group: {FoodGroup}";
        }
    }

    // Class to represent a recipe step
    internal class RecipeStep
    {
        public string Description { get; }

        public RecipeStep(string description)
        {
            Description = description;
        }

        public override string ToString()
        {
            return Description;
        }
    }

    // Unit test class
    internal static class RecipeUnitTest
    {
        public static void TestTotalCaloriesCalculation()
        {
            Recipe recipe = new Recipe("Test Recipe");
            recipe.AddIngredient(new Ingredient("Ingredient 1", 100, "g", 50, "Group 1"));
            recipe.AddIngredient(new Ingredient("Ingredient 2", 200, "g", 75, "Group 2"));
            recipe.AddIngredient(new Ingredient("Ingredient 3", 150, "g", 100, "Group 3"));

            double expectedTotalCalories = 50 + 75 + 100;
            double actualTotalCalories = RecipeManager.CalculateTotalCalories(recipe);

            if (expectedTotalCalories == actualTotalCalories)
            {
                Console.WriteLine("Total calories calculation test passed.");
            }
            else
            {
                Console.WriteLine($"Total calories calculation test failed. Expected: {expectedTotalCalories}, Actual: {actualTotalCalories}");
            }
        }
    }
}
